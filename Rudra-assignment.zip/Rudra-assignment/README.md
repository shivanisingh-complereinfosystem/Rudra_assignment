# README #

This README would normally document whatever steps are necessary to get your application up and running.
### How do I get set up? ###

* Run npm install 
* Run node server.js in terminal

### apis
 ### signup
  * localhost:4567/auth/signup
    * body: {"email":"your email","password":"your password"}
### login
  * localhost:4567/auth/login
    * body: {"email":"your email","password":"your password"}
### forgot
  * localhost:4567/auth/forgot
    * body: {"email":"your email"}
### reset
  * localhost:4567/auth/forgot
    * body: {"id":"your id","password":"new password"}  



